
public class DecisaoComposta {
	
	public void DecisaoComposto(int valor1, int valor2) {
		if (valor1 < valor2) {
	System.out.println("VALOR 1: " + valor1 + " � MENOR QUE VALOR 2:" + valor2);
		}else{
	System.out.println("VALOR 1: " + valor1 + " � MAIOR OU IGUAL QUE VALOR 2" + valor2);
			
		}
	}
	
}
