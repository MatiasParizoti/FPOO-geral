
public class atividade2 {
	
	public void ExibirMaior(int n1,int n2,int n3) {
		
		if(n1 > n2) {
			if(n1 > n3) 
				System.out.print("O VALOR MAIOR �:"+ n1);
			}else { if(n2 > n3) {
					System.out.print("O VALOR MAOIR �: "+ n2);
				}else { System.out.print("O VALOR MAIOR �: "+ n3);
					}
				}
			}
	} 

	